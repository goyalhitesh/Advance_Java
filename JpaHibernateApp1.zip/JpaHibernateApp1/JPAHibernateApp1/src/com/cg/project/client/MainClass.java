package com.cg.project.client;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.project.beans.Associate;
import com.cg.project.beans.BankDetails;
import com.cg.project.beans.Salary;
import com.cg.project.daoservices.AssociateDAO;
import com.cg.project.daoservices.AssociateDAOImpl;
public class MainClass {
	public static void main(String[] args) {
		/*EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager = factory.createEntityManager();
		
		AssociateDAO dao = new AssociateDAOImpl();
		Associate1 associate = new Associate1("Hitesh", "Goyal", "Sr. Analyst", "hitesh@gmail.com");
		associate = dao.save(associate);
		
		int associateId = associate.getAssociateId();
		System.out.println("associate Id = "+associate.getAssociateId());
		System.out.println(dao.findOne(1));*/
		
		AssociateDAO dao = new AssociateDAOImpl();
		Associate associate = new Associate(8500, "Hitesh", "Goyal", "Software Engg", "Sr. Analyst", "ASGBV2541C", "hitesh@gmail.com", new BankDetails(55142552, "SBI", "SBIN0050023"), new Salary(56000, 3000, 1520, 1258, 1295, 542, 2042, 2042, 5015, 695000, 700000));
		associate = dao.save(associate);
		System.out.println(associate);
	}
}