package com.cg.project.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.daoservices.BankingDAOImpl;
import com.cg.project.daoservices.bankingDAO;
import com.cg.project.exceptions.AccountBlockedException;
import com.cg.project.exceptions.AccountNotFoundException;
import com.cg.project.exceptions.BankingServicesDownException;
import com.cg.project.exceptions.InsufficientAmountException;
import com.cg.project.exceptions.InvalidAccountTypeException;
import com.cg.project.exceptions.InvalidAmountException;
import com.cg.project.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	bankingDAO bankingDAO = new BankingDAOImpl();
	static int number_of_pin_try=0;

	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException {
			Account account = new Account(accountType, initBalance);
			account.setStatus("Active");
			account=bankingDAO.save(account);
			return account.getAccountNo();
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException {
		Account account=bankingDAO.findOne(accountNo);
		if(account!=null){
			bankingDAO.depositToAccount(accountNo, amount);
	}
		
		return amount;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		Account account = bankingDAO.withdrawToAccount(accountNo, amount, pinNumber);
		if(account==null)throw new AccountNotFoundException("Account Not Found! Please enter a valid account number.");
		if(!account.getStatus().equalsIgnoreCase("Active")) throw new AccountBlockedException("Your Account is blocked. Please contact your home branch.");
		if((account.getAccountBalance()<(amount+1000))) throw new InsufficientAmountException("Insufficient Amount!!");
		if(account.getPinNumber()==0){
			number_of_pin_try++;
			throw new InvalidPinNumberException("Incorrect Pin!! Try again.");
		}
		if(number_of_pin_try!=3){
			number_of_pin_try=0;
			return account.getAccountBalance();
		}
		else{
			number_of_pin_try=0;
			account.setStatus("Blocked");
			throw new AccountBlockedException("Your account has been blocked. Please contact home branch.");
		}
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		Account account = bankingDAO.withdrawFromAccount(accountNoFrom, transferAmount,pinNumber);
		if(account==null)throw new AccountNotFoundException("Account Not Found! Please enter a valid account number.");
		if(!account.getStatus().equalsIgnoreCase("Active")) throw new AccountBlockedException("Your Account is blocked. Please contact your home branch.");
		if((account.getAccountBalance()<(transferAmount+1000))) throw new InsufficientAmountException("Insufficient Amount!!");
		if(account.getPinNumber()==0){
			number_of_pin_try++;
			throw new InvalidPinNumberException("Incorrect Pin!! Try again.");
		}
		if (account.getAccountBalance()<0)	throw new InsufficientAmountException("The transaction got failed due to insufficient balance in the account.");
		if(number_of_pin_try!=3){
			number_of_pin_try=0;
			account = bankingDAO.depositAmountToAccount(accountNoTo, transferAmount);
			if (account == null) {
				bankingDAO.depositAmountToAccount(accountNoFrom, transferAmount);
				throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			}	
			if (account.getStatus().equalsIgnoreCase("Blocked")) {
				bankingDAO.depositAmountToAccount(accountNoFrom, transferAmount);
				throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
			}
			return true;
		}
		else{
			number_of_pin_try=0;
			account.setStatus("Blocked");
			throw new AccountBlockedException("Your account has been blocked. Please contact home branch.");
		}	
	}

	@Override
	public Account getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
		Account account = bankingDAO.findOne(accountNo);
		if(account == null) throw new AccountNotFoundException("Account Not Found! Please enter a valid account number.");
		return account;
	}

	@Override
	public ArrayList<Account> getAllAccountDetails()
			throws BankingServicesDownException, AccountNotFoundException {
		return bankingDAO.findAll();
	}

	@Override
	public ArrayList<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return bankingDAO.findAllTransaction();
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException,
			AccountBlockedException {
		// TODO Auto-generated method stub
		return null;
	}
}
