package com.cg.project.daoservices;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.services.BankingServices;
import com.cg.project.services.BankingServicesImpl;
import com.cg.project.util.EntityManagerFactoryProvider;

public class BankingDAOImpl implements bankingDAO{
	private EntityManagerFactory factory = EntityManagerFactoryProvider.geEntityManagerFactory();
	@Override
	public Account save(Account account) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}

	@Override
	public Account findOne(long accountNo) {
		EntityManager entityManager = factory.createEntityManager();
		return entityManager.find(Account.class, accountNo);
	}

	@Override
	public ArrayList<Account> findAll() {
		EntityManager entityManager = factory.createEntityManager();
		Query query = entityManager.createNamedQuery("getAllAccounts");
		ArrayList<Account> list = (ArrayList<Account>) query.getResultList();
		return list;
	}

	@Override
	public Account depositToAccount(long accountNo, float amount) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		Account account = findOne(accountNo);
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction = saveTransaction(accountNo, "Deposit", amount);
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}

	@Override
	public Account withdrawToAccount(long accountNo, float amount, int pinNumber) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		Account account = findOne(accountNo);
		account.setAccountBalance(account.getAccountBalance()-amount);
		Transaction transaction = saveTransaction(accountNo, "Deposit", amount);
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}

	@Override
	public ArrayList<Transaction> findAllTransaction() {
		EntityManager entityManager = factory.createEntityManager();
		Query query = entityManager.createNamedQuery("getAllTransactions");
		ArrayList<Transaction> list = (ArrayList<Transaction>) query.getResultList();
		return list;
	}

	@Override
	public Account withdrawFromAccount(long accountNoFrom,
			float transferAmount, int pinNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account depositAmountToAccount(long accountNoTo, float transferAmount) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public boolean update(Account account) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Transaction saveTransaction(long accountNo, String transactionType,
			float amount) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		Account account = findOne(accountNo);
		Transaction transaction = new Transaction(amount, transactionType, account);
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return transaction;
	}
}
