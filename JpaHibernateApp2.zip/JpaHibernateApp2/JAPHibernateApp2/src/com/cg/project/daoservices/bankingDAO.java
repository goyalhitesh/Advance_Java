package com.cg.project.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;

public interface bankingDAO {
	
	Account save(Account account);

	Account findOne(long accountNo);

	ArrayList<Account> findAll();

	Account depositToAccount(long accountNo, float amount);

	Account withdrawToAccount(long accountNo, float amount, int pinNumber);

	ArrayList<Transaction> findAllTransaction();

	Account withdrawFromAccount(long accountNoFrom, float transferAmount,int pinNumber);

	Account depositAmountToAccount(long accountNoTo, float transferAmount);

	boolean update(Account account);
	
	Transaction saveTransaction(long accountNo, String transactionType, float amount);
}
